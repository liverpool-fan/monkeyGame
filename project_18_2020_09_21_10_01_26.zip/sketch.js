var banana,bananaImage
var obsacle,obstacleImage
var obstacleGroup,bananaGroup
var score
var monkey,monkeyAnimation
var background,backgroundImage
var ground
function preload() {
  backgroundImage=loadImage("jungle.jpg")
  monkeyAnimation=loadAnimation("monkey_01.png","monkey_02.png","monkey_03.png","monkey_04.png","monkey_05.png","monkey_06.png","monkey_07.png","monkey_08.png","monkey_09.png","monkey_10.png")
bananaImage=loadImage("banana.png")
  obstacleImage=loadImage("stane.png")
}

function setup() {
  background = createSprite(200,200,400,400)
  background.addImage("jungle",backgroundImage)
  background.velocityX = -3
  if(background.x < 0){
    background.x = 200
  }
  ground.visibility = false
  monkey = createSprite(395,10,10,10)
  mankey.addAnimation("runner",monkeyAnimation)
  createCanvas(400, 400);
}

function draw() {
  bananaGroup = createGroup()
  obsteclegroup = createGroup()
  if (monkey.Istouching(banana)){
      score += 2
    food.destroyEach
    switch(score){
      case 10: monkey.scale=0.12
        break;
        case 20: monkey.scale=0.14
        break;
        case 30: monkey.scale=0.16
        break;
        case 40: monkey.scale=0.18
        break;  
    }
  }
      if(monkey.isTouching(obstacle){
         score = 0
         monkey.sclae(0.1)
        obstacle.destroyEach
  }
    text("score:   "+score,350,50)  
  food()
  obstecles()
  background(220);
}
function food(){
 if(frameCount % 80 === 0) {
     banana = createSprite(400,randomNumber(120,200),10,10);
    banana.addImage( "Banana",bananaImage)
    banana.scale = 0.05
    banana.velocityX = - 6
   banana.lifetime = 70
    bannanagroup.add(banana);
 }
}
function obstecles(){
 if(frameCount % 300 === 0) {
    obsacle = createSprite(400,380,10,10);
    obsacle.addImage( "Stone",obstacleImage)
    obsacle.scale = 0.4
    obsacle.velocityX = - 6
   obsacle.lifetime = 70
    obsteclegroup.add(obsacle)
    
}
}